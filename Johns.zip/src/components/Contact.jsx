import React from 'react'

const Contact = () => {
  return (
    <div>Contact with us</div>
  )
}

export default Contact