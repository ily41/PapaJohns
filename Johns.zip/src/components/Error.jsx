import React from 'react'

const Error = () => {
  return (
    <h2>404 Not found</h2>
  )
}

export default Error